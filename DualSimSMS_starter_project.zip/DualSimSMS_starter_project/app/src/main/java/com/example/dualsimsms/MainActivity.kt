package com.example.dualsimsms

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import android.telephony.SmsMessage
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("dual_sim_sms", MODE_PRIVATE) }
    private lateinit var simSpinner: Spinner
    private lateinit var messageEdit: EditText
    private lateinit var logView: TextView
    private lateinit var statusView: TextView
    private var subs: List<android.telephony.SubscriptionInfo> = emptyList()
    private var pendingCnic: String? = null
    private var receiverRegistered = false

    private val smsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != "android.provider.Telephony.SMS_RECEIVED") return
            val bundle = intent.extras ?: return
            val pdus = bundle.get("pdus") as? Array<*> ?: return
            val format = bundle.getString("format")
            val body = pdus.mapNotNull {
                try {
                    SmsMessage.createFromPdu(it as ByteArray, format).messageBody
                } catch (_: Exception) { null }
            }.joinToString("")
            val sender = pdus.firstOrNull()?.let {
                try { SmsMessage.createFromPdu(it as ByteArray, format).originatingAddress } catch (_: Exception) { null }
            } ?: "unknown"

            // Only parse replies from the configured first short code.
            if (sender.filter { it.isDigit() }.takeLast(4) != "7911") {
                appendLog("Incoming SMS from $sender (not processed).")
                return
            }
            val cnic = Regex("""(?<!\d)\d{13}(?!\d)""").find(body)?.value
            if (cnic == null) {
                appendLog("Reply from 7911 received, but no 13-digit CNIC was found. Check the reply manually.")
                showStatus("7911 reply received; CNIC not detected.")
                return
            }
            pendingCnic = cnic
            val template = prefs.getString("template", "REG {CNIC} MAV2433 B 13112025")
                ?: "REG {CNIC} MAV2433 B 13112025"
            val filled = template.replace("{CNIC}", cnic, ignoreCase = true)
            runOnUiThread {
                showStatus("CNIC found in 7911 reply. Review before sending.")
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Review message to 9771")
                    .setMessage("Reply received from 7911.\n\nExtracted CNIC: $cnic\n\nMessage:\n$filled\n\nSend this message to 9771?")
                    .setNegativeButton("Cancel") { _, _ ->
                        appendLog("Second SMS cancelled by user.")
                    }
                    .setPositiveButton("Review / Send") { _, _ ->
                        messageEdit.setText(filled)
                        confirmAndSendSecond(filled)
                    }
                    .show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestNeededPermissions()
        refreshSims()
        if (prefs.getString("template", null) == null) {
            prefs.edit().putString("template", "REG {CNIC} MAV2433 B 13112025").apply()
        }
        messageEdit.setText(prefs.getString("template", "REG {CNIC} MAV2433 B 13112025"))
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }
        root.addView(TextView(this).apply {
            text = "Dual SIM SMS"
            textSize = 24f
        })
        root.addView(TextView(this).apply {
            text = "Select the SIM used for both steps"
            textSize = 14f
        })
        simSpinner = Spinner(this)
        root.addView(simSpinner)
        root.addView(Button(this).apply {
            text = "Refresh SIMs"
            setOnClickListener { refreshSims() }
        })
        root.addView(TextView(this).apply {
            text = "Message template for 9771 (use {CNIC})"
            textSize = 14f
        })
        messageEdit = EditText(this).apply {
            minLines = 2
            setText("REG {CNIC} MAV2433 B 13112025")
        }
        root.addView(messageEdit)
        root.addView(Button(this).apply {
            text = "Save template"
            setOnClickListener {
                prefs.edit().putString("template", messageEdit.text.toString()).apply()
                showStatus("Template saved on this phone.")
                appendLog("Template saved.")
            }
        })
        root.addView(Button(this).apply {
            text = "Send V to 7911"
            setOnClickListener { confirmFirstSend() }
        })
        statusView = TextView(this).apply {
            text = "Ready. SMS permissions are required."
            textSize = 14f
        }
        root.addView(statusView)
        root.addView(TextView(this).apply {
            text = "Activity / results"
            textSize = 18f
        })
        logView = TextView(this).apply { textSize = 12f }
        val scroll = ScrollView(this)
        scroll.addView(logView)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun requestNeededPermissions() {
        val needed = arrayOf(
            Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_PHONE_STATE
        ).filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (needed.isNotEmpty()) requestPermissions(needed.toTypedArray(), 44)
    }

    private fun refreshSims() {
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            simSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Grant Phone permission first"))
            return
        }
        try {
            subs = getSystemService(TELEPHONY_SUBSCRIPTION_SERVICE).let {
                (it as SubscriptionManager).activeSubscriptionInfoList ?: emptyList()
            }
            val labels = if (subs.isEmpty()) listOf("No active SIM found") else subs.mapIndexed { index, s ->
                "SIM ${index + 1} — ${s.carrierName} (slot ${s.simSlotIndex + 1})"
            }
            simSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        } catch (e: Exception) {
            simSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Unable to read SIMs"))
            showStatus("Could not read SIMs: ${e.message}")
        }
    }

    private fun selectedSubscriptionId(): Int? {
        if (subs.isEmpty()) return null
        val index = simSpinner.selectedItemPosition
        return subs.getOrNull(index)?.subscriptionId
    }

    private fun confirmFirstSend() {
        if (!hasSmsPermissions()) return
        AlertDialog.Builder(this)
            .setTitle("Confirm SMS")
            .setMessage("Send the saved text 'V' to 7911 using the selected SIM?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Send") { _, _ -> sendSms("7911", "V", "Initial SMS to 7911") }
            .show()
    }

    private fun confirmAndSendSecond(text: String) {
        AlertDialog.Builder(this)
            .setTitle("Final confirmation")
            .setMessage("Send this exact message to 9771?\n\n$text")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Send SMS") { _, _ -> sendSms("9771", text, "Second SMS to 9771") }
            .show()
    }

    private fun hasSmsPermissions(): Boolean {
        val ok = checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
        if (!ok) {
            showStatus("Grant SMS and Phone permissions in Android settings, then reopen the app.")
            requestNeededPermissions()
        }
        return ok
    }

    private fun sendSms(destination: String, body: String, label: String) {
        if (!hasSmsPermissions()) return
        val subId = selectedSubscriptionId()
        if (subId == null) {
            showStatus("No active SIM selected. Insert a SIM and tap Refresh SIMs.")
            return
        }
        try {
            val smsManager = if (android.os.Build.VERSION.SDK_INT >= 31) {
                getSystemService(SmsManager::class.java).createForSubscriptionId(subId)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getSmsManagerForSubscriptionId(subId)
            }
            smsManager.sendTextMessage(destination, null, body, null, null)
            appendLog("$label: send request submitted via selected SIM.")
            showStatus("SMS send request submitted. Carrier delivery is not yet confirmed.")
        } catch (e: Exception) {
            appendLog("$label failed: ${e.message}")
            showStatus("Send failed: ${e.message}")
        }
    }

    private fun appendLog(line: String) {
        runOnUiThread {
            val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            logView.text = "[$stamp] $line\n" + logView.text
            // Keep the on-screen log from growing indefinitely.
            logView.text = logView.text.take(6000)
        }
    }

    private fun showStatus(text: String) {
        if (::statusView.isInitialized) statusView.text = text
    }

    override fun onResume() {
        super.onResume()
        if (!receiverRegistered &&
            checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED) {
            registerReceiver(smsReceiver, IntentFilter("android.provider.Telephony.SMS_RECEIVED"))
            receiverRegistered = true
        }
    }

    override fun onPause() {
        if (receiverRegistered) {
            try { unregisterReceiver(smsReceiver) } catch (_: Exception) {}
            receiverRegistered = false
        }
        super.onPause()
    }
}
