DualSimSMS — starter Android project
====================================

What it does
- Lets you select an active SIM subscription.
- Sends "V" to 7911 only after you tap the button and confirm.
- When the app is open, checks incoming SMS from 7911 for a 13-digit CNIC.
- Inserts that number into the saved 9771 template using {CNIC}.
- Shows a review and confirmation dialog before sending to 9771.
- Saves the message template locally and shows a simple in-app activity log.

Important limitations
- This is starter source code, not a built or tested APK.
- It must be built with Android Studio or another compatible Android build environment.
- Incoming SMS is only handled while the app is open/foregrounded in this starter version.
- SIM numbering shown is based on Android's active subscription list; device/manufacturer behavior can differ.
- The activity log records send requests, not verified delivery. SMS delivery status requires sent/delivery PendingIntents and carrier support.
- Verify that the short codes and message format are correct and authorized before use.
- CNIC is sensitive personal data. Keep the phone secure and do not share logs/screenshots containing CNIC.
- Do not use this for other people's CNICs without their permission.

Build
1. Open the folder in Android Studio on a computer, or upload the ZIP to a trusted Android build environment that supports Gradle.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the APK on your own Android phone.
5. Grant SMS and Phone permissions when asked.
6. Insert the SIM(s), tap Refresh SIMs, choose the SIM, and test with permission and carrier charges in mind.

This project uses Android SMS permissions and is not suitable for Play Store publishing without reviewing current Google Play SMS permission policy.
